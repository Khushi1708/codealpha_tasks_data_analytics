import pandas as pd

def analyze_data(filename="quotes_dataset.csv"):
    print(f"--- Analyzing {filename} ---\n")
    
    try:
        df = pd.read_csv(filename)
    except FileNotFoundError:
        print(f"Error: Could not find {filename}")
        return

    # Basic Info
    print(f"Total number of quotes: {len(df)}")
    
    # Unique Authors
    unique_authors = df['Author'].nunique()
    print(f"Number of unique authors: {unique_authors}")
    
    # Top 5 Authors by number of quotes
    print("\n--- Top 5 Authors by Quote Count ---")
    top_authors = df['Author'].value_counts().head(5)
    print(top_authors.to_string())
    
    # Analyzing Tags (Splitting comma-separated tags and counting them)
    print("\n--- Top 5 Most Common Tags ---")
    
    # Dropna to handle quotes with no tags, then split the strings and explode the lists
    tags_series = df['Tags'].dropna().str.split(', ').explode()
    top_tags = tags_series.value_counts().head(5)
    print(top_tags.to_string())
    
    print("\n--- Average Quotes per Author ---")
    print(f"{len(df) / unique_authors:.2f}")

if __name__ == "__main__":
    analyze_data()
