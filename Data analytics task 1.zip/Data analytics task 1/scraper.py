import requests
from bs4 import BeautifulSoup
import pandas as pd

def scrape_quotes():
    base_url = "http://quotes.toscrape.com"
    page_url = "/page/1/"
    quotes_data = []

    print(f"Starting to scrape {base_url}...")

    # Loop through all pages
    while page_url:
        print(f"Scraping {base_url}{page_url}")
        response = requests.get(base_url + page_url)
        
        # Check if the request was successful
        if response.status_code != 200:
            print(f"Failed to retrieve page: {response.status_code}")
            break
            
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find all quote elements on the current page
        quotes = soup.find_all('div', class_='quote')
        
        for quote in quotes:
            # Extract the text of the quote
            text = quote.find('span', class_='text').text
            
            # Extract the author
            author = quote.find('small', class_='author').text
            
            # Extract the tags associated with the quote
            tags = [tag.text for tag in quote.find('div', class_='tags').find_all('a', class_='tag')]
            
            quotes_data.append({
                'Quote': text,
                'Author': author,
                'Tags': ', '.join(tags)
            })
            
        # Look for the 'Next' button to navigate to the next page
        next_button = soup.find('li', class_='next')
        if next_button:
            page_url = next_button.find('a')['href']
        else:
            page_url = None

    print(f"Scraped {len(quotes_data)} quotes in total.")
    return quotes_data

def save_to_csv(data, filename="quotes_dataset.csv"):
    if not data:
        print("No data to save.")
        return
        
    print(f"Saving data to {filename}...")
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False, encoding='utf-8')
    print("Dataset saved successfully.")

if __name__ == "__main__":
    extracted_data = scrape_quotes()
    save_to_csv(extracted_data)
