import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import altair as alt
import os
import io
from sample_data import get_sales_data, get_support_data

# Page Configuration
st.set_page_config(
    page_title="NovaVis | Premium Data Visualizer & Storyteller",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize Session State
if "storyboard" not in st.session_state:
    st.session_state.storyboard = []  # List of dicts: {"type": "chart"/"note", "content": data, "title": str}

if "loaded_df" not in st.session_state:
    st.session_state.loaded_df = None

if "dataset_name" not in st.session_state:
    st.session_state.dataset_name = "None"

# Inject Custom CSS
def local_css(file_name):
    if os.path.exists(file_name):
        with open(file_name) as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    else:
        st.warning("Styles stylesheet not found. Falling back to default styles.")

local_css("styles.css")

# Theme Palette Definitions
PALETTES = {
    "Cool Tech (Indigo/Violet)": ["#6366f1", "#8b5cf6", "#a855f7", "#ec4899", "#f43f5e"],
    "Coral Sunset (Orange/Red)": ["#f97316", "#f43f5e", "#ef4444", "#ec4899", "#8b5cf6"],
    "Emerald Garden (Green/Teal)": ["#10b981", "#14b8a6", "#06b6d4", "#3b82f6", "#6366f1"],
    "Sleek Monochrome (Gray/Silver)": ["#64748b", "#475569", "#334155", "#cbd5e1", "#94a3b8"]
}

# Sidebar Branding and Controls
with st.sidebar:
    st.markdown('<div style="text-align: center; margin-bottom: 2rem;">', unsafe_allow_html=True)
    st.markdown('<h1 style="color: #ffffff; font-size: 2.2rem; font-weight: 800; margin-bottom: 0.2rem;">📊 NovaVis</h1>', unsafe_allow_html=True)
    st.markdown('<p style="color: #64748b; font-size: 0.9rem;">Intelligence in Visualization</p>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('<div class="gradient-divider" style="margin: 1rem 0;"></div>', unsafe_allow_html=True)
    
    st.subheader("📁 Data Source Selection")
    data_source = st.radio(
        "Choose Data Input Method:",
        ["Built-in: E-Commerce Sales", "Built-in: Tech Support Logs", "Upload Custom CSV / XLSX"],
        index=0
    )
    
    uploaded_file = None
    if data_source == "Upload Custom CSV / XLSX":
        uploaded_file = st.file_uploader(
            "Upload your CSV or Excel file",
            type=["csv", "xlsx", "xls"],
            help="Supported formats: CSV, XLSX"
        )
        
    st.markdown('<div class="gradient-divider" style="margin: 1.5rem 0;"></div>', unsafe_allow_html=True)
    
    st.subheader("🎨 Visual Styling Config")
    selected_theme = st.selectbox(
        "Chart Theme Palette:",
        list(PALETTES.keys())
    )
    colors = PALETTES[selected_theme]
    
    st.markdown('<div class="gradient-divider" style="margin: 1.5rem 0;"></div>', unsafe_allow_html=True)
    st.subheader("📋 Storyboard Stats")
    item_count = len(st.session_state.storyboard)
    st.markdown(f"Saved Assets: **{item_count}** items")
    if st.button("🗑️ Clear Storyboard"):
        st.session_state.storyboard = []
        st.success("Storyboard cleared!")
        st.rerun()

# Load Data based on selection
@st.cache_data
def load_builtin_sales():
    return get_sales_data()

@st.cache_data
def load_builtin_support():
    return get_support_data()

def parse_uploaded_file(file):
    try:
        filename = file.name
        if filename.endswith(".csv"):
            return pd.read_csv(file)
        else:
            return pd.read_excel(file)
    except Exception as e:
        st.error(f"Error loading file: {e}")
        return None

# Resolve DataFrame to session state
if "Built-in: E-Commerce Sales" in data_source:
    st.session_state.loaded_df = load_builtin_sales()
    st.session_state.dataset_name = "SaaS E-Commerce Sales"
elif "Built-in: Tech Support Logs" in data_source:
    st.session_state.loaded_df = load_builtin_support()
    st.session_state.dataset_name = "Tech Support Performance"
else:
    if uploaded_file is not None:
        custom_df = parse_uploaded_file(uploaded_file)
        if custom_df is not None:
            st.session_state.loaded_df = custom_df
            st.session_state.dataset_name = uploaded_file.name
    else:
        st.session_state.loaded_df = None
        st.session_state.dataset_name = "None"

# Main Layout
st.markdown('<h1 class="title-gradient">Data Visualization Studio</h1>', unsafe_allow_html=True)
st.markdown('<p class="subtitle-gradient">Create, customize, analyze, and build narratives from your dataset</p>', unsafe_allow_html=True)

if st.session_state.loaded_df is None:
    st.info("👋 Welcome! Please upload a custom CSV/Excel file in the sidebar to start, or choose one of our built-in datasets.")
    st.stop()

df = st.session_state.loaded_df.copy()

# Auto-parse Date columns
for col in df.columns:
    if df[col].dtype == 'object':
        try:
            # Check if it looks like a date
            first_val = str(df[col].dropna().iloc[0]) if not df[col].dropna().empty else ""
            if any(char.isdigit() for char in first_val) and any(sep in first_val for sep in ['-', '/', ':']):
                df[col] = pd.to_datetime(df[col])
        except Exception:
            pass

# Create Main Tabs
tab_portal, tab_builder, tab_insights, tab_storyboard = st.tabs([
    "📁 Data Portal",
    "📊 Interactive Chart Builder",
    "💡 Automated Insights",
    "📝 Storyboard & Reporting"
])

# ==========================================
# TAB 1: DATA PORTAL
# ==========================================
with tab_portal:
    st.markdown("### 📁 Dataset Overview")
    
    # KPI Grid
    kpi_col1, kpi_col2, kpi_col3, kpi_col4 = st.columns(4)
    
    num_rows, num_cols = df.shape
    missing_cells = df.isnull().sum().sum()
    total_cells = df.size
    missing_pct = (missing_cells / total_cells * 100) if total_cells > 0 else 0
    duplicate_rows = df.duplicated().sum()
    
    with kpi_col1:
        st.markdown(f"""
        <div class="premium-card">
            <div class="kpi-title">Active Dataset</div>
            <div class="kpi-value">{st.session_state.dataset_name}</div>
            <div class="kpi-trend neutral">Source: {data_source.split(':')[0]}</div>
        </div>
        """, unsafe_allow_html=True)
        
    with kpi_col2:
        st.markdown(f"""
        <div class="premium-card">
            <div class="kpi-title">Data Dimensions</div>
            <div class="kpi-value">{num_rows:,} x {num_cols}</div>
            <div class="kpi-trend positive">↑ Records loaded successfully</div>
        </div>
        """, unsafe_allow_html=True)
        
    with kpi_col3:
        status_color = "positive" if missing_pct == 0 else ("neutral" if missing_pct < 5 else "negative")
        st.markdown(f"""
        <div class="premium-card">
            <div class="kpi-title">Data Completeness</div>
            <div class="kpi-value">{100 - missing_pct:.1f}%</div>
            <div class="kpi-trend {status_color}">{missing_cells:,} missing cells ({missing_pct:.1f}%)</div>
        </div>
        """, unsafe_allow_html=True)
        
    with kpi_col4:
        dup_color = "positive" if duplicate_rows == 0 else "negative"
        st.markdown(f"""
        <div class="premium-card">
            <div class="kpi-title">Duplicate Rows</div>
            <div class="kpi-value">{duplicate_rows}</div>
            <div class="kpi-trend {dup_color}">{"No duplicates detected" if duplicate_rows == 0 else f"{duplicate_rows} redundant rows found"}</div>
        </div>
        """, unsafe_allow_html=True)
        
    col_table, col_summary = st.columns([2, 1])
    
    with col_table:
        st.markdown("#### 🔍 Data Preview (First 15 Rows)")
        st.dataframe(df.head(15), use_container_width=True)
        
    with col_summary:
        st.markdown("#### 🔬 Column Metadata")
        meta_data = []
        for col in df.columns:
            dtype = str(df[col].dtype)
            missing = df[col].isnull().sum()
            missing_pct_col = (missing / len(df) * 100)
            unique_vals = df[col].nunique()
            meta_data.append({
                "Column": col,
                "Type": dtype,
                "Unique": unique_vals,
                "Missing %": f"{missing_pct_col:.1f}%"
            })
        st.dataframe(pd.DataFrame(meta_data), use_container_width=True, hide_index=True)
        
    # Statistical Summary
    st.markdown('<div class="gradient-divider" style="margin: 1.5rem 0;"></div>', unsafe_allow_html=True)
    st.markdown("#### 📈 Statistical Summary (Numerical Data)")
    numerical_df = df.select_dtypes(include=[np.number])
    if not numerical_df.empty:
        st.dataframe(numerical_df.describe().T, use_container_width=True)
    else:
        st.warning("No numerical columns found in this dataset.")

# ==========================================
# TAB 2: INTERACTIVE CHART BUILDER
# ==========================================
with tab_builder:
    st.markdown("### 📊 Custom Visualizer")
    
    col_controls, col_display = st.columns([1, 2])
    
    all_cols = list(df.columns)
    num_cols_list = list(df.select_dtypes(include=[np.number]).columns)
    cat_cols_list = list(df.select_dtypes(exclude=[np.number]).columns)
    
    with col_controls:
        st.markdown('<div class="premium-card">', unsafe_allow_html=True)
        st.markdown("##### ⚙️ Configurations")
        
        chart_type = st.selectbox(
            "Chart Type",
            ["Bar Chart", "Line Chart", "Area Chart", "Scatter Plot", "Box Plot", "Correlation Heatmap"]
        )
        
        x_axis = None
        y_axis = None
        color_by = None
        size_by = None
        
        if chart_type != "Correlation Heatmap":
            x_axis = st.selectbox("X-Axis Column", all_cols)
            
            # Select Y-axis (prefer numeric)
            y_opts = ["None"] + all_cols
            y_axis = st.selectbox("Y-Axis Column", y_opts, index=1 if len(y_opts) > 1 else 0)
            
            color_opts = ["None"] + all_cols
            color_by = st.selectbox("Color / Group By", color_opts, index=0)
            
            if chart_type == "Scatter Plot":
                size_opts = ["None"] + num_cols_list
                size_by = st.selectbox("Marker Size (Numeric)", size_opts, index=0)
        
        st.markdown('<div class="gradient-divider" style="margin: 1rem 0;"></div>', unsafe_allow_html=True)
        st.markdown("##### 🎨 Polish Details")
        chart_title = st.text_input("Chart Title", value=f"{chart_type} of {x_axis}" if chart_type != "Correlation Heatmap" else "Correlation Matrix")
        
        # Sub-sampling or aggregation options
        aggregate_data = False
        agg_func = "mean"
        if chart_type in ["Bar Chart", "Line Chart", "Area Chart"] and y_axis != "None":
            # Check if X is categorical or datetime, which typically requires aggregation if non-unique
            if df[x_axis].nunique() < len(df):
                aggregate_data = st.checkbox("Aggregate duplicate X values?", value=True)
                agg_func = st.selectbox("Aggregation Method", ["mean", "sum", "count", "min", "max"])
        
        save_chart = st.button("💾 Save Chart to Storyboard")
        st.markdown('</div>', unsafe_allow_html=True)
        
    with col_display:
        st.markdown(f"#### 📺 Visual: {chart_title}")
        
        plot_df = df.copy()
        
        # Generate Charts
        chart_to_save = None
        
        try:
            if chart_type == "Correlation Heatmap":
                if len(num_cols_list) < 2:
                    st.warning("Need at least 2 numerical columns to construct a correlation heatmap.")
                else:
                    corr = plot_df[num_cols_list].corr()
                    
                    fig, ax = plt.subplots(figsize=(8, 6))
                    fig.patch.set_facecolor('#0f172a')
                    ax.set_facecolor('#0f172a')
                    
                    # Custom colormap matching palette
                    cmap = sns.diverging_palette(240, 10, as_cmap=True) if selected_theme != "Emerald Garden (Green/Teal)" else sns.diverging_palette(150, 10, as_cmap=True)
                    
                    sns.heatmap(
                        corr, 
                        annot=True, 
                        cmap=cmap, 
                        fmt=".2f", 
                        linewidths=.5, 
                        ax=ax,
                        annot_kws={"size": 10, "color": "white", "weight": "bold"},
                        cbar_kws={"shrink": .8}
                    )
                    
                    # Style labels
                    ax.tick_params(colors='white', labelsize=10)
                    plt.title(chart_title, color='white', fontsize=14, pad=15)
                    st.pyplot(fig)
                    
                    # Keep static matplotlib figure for storyboard
                    chart_to_save = fig
                    
            elif x_axis:
                # Prepare data for plot
                y_val = None if y_axis == "None" else y_axis
                
                # Check for Aggregations
                if aggregate_data and y_val:
                    group_cols = [x_axis]
                    if color_by != "None":
                        group_cols.append(color_by)
                    
                    # Handle datetimes properly
                    if pd.api.types.is_datetime64_any_dtype(plot_df[x_axis]):
                        # If date, let's sort by it
                        plot_df = plot_df.groupby(group_cols, as_index=False).agg({y_val: agg_func})
                        plot_df = plot_df.sort_values(x_axis)
                    else:
                        plot_df = plot_df.groupby(group_cols, as_index=False).agg({y_val: agg_func})
                
                # Dynamic Altair Chart construction for highly interactive Web graphics
                if chart_type in ["Bar Chart", "Line Chart", "Area Chart", "Scatter Plot"]:
                    
                    # Determine chart encoding bases
                    x_type = 'T' if pd.api.types.is_datetime64_any_dtype(plot_df[x_axis]) else 'N' if pd.api.types.is_numeric_dtype(plot_df[x_axis]) else 'N'
                    if x_type == 'N' and plot_df[x_axis].nunique() < 20:
                        x_type = 'O' # Treat as Ordinal if numeric but discrete
                    
                    # Set up Altair scale colors
                    color_scale = alt.Scale(range=colors)
                    
                    # Basic interactive encoding
                    x_encoding = alt.X(x_axis, title=x_axis, type=x_type)
                    y_encoding = alt.Y(y_val, title=f"{agg_func.capitalize()} of {y_val}" if aggregate_data else y_val) if y_val else alt.Y('count()', title='Record Count')
                    
                    encoding_args = {
                        "x": x_encoding,
                        "y": y_encoding,
                        "tooltip": [x_axis, y_val] if y_val else [x_axis]
                    }
                    
                    if color_by != "None":
                        encoding_args["color"] = alt.Color(color_by, scale=color_scale, title=color_by)
                        if color_by not in encoding_args["tooltip"]:
                            encoding_args["tooltip"].append(color_by)
                            
                    if chart_type == "Scatter Plot" and size_by != "None":
                        encoding_args["size"] = alt.Size(size_by, title=size_by)
                    
                    # Build Altair Mark
                    if chart_type == "Bar Chart":
                        chart = alt.Chart(plot_df).mark_bar(cornerRadiusTopLeft=4, cornerRadiusTopRight=4).encode(**encoding_args)
                    elif chart_type == "Line Chart":
                        chart = alt.Chart(plot_df).mark_line(strokeWidth=3, interpolate='monotone').encode(**encoding_args)
                    elif chart_type == "Area Chart":
                        chart = alt.Chart(plot_df).mark_area(opacity=0.6).encode(**encoding_args)
                    else: # Scatter
                        chart = alt.Chart(plot_df).mark_circle(size=80, opacity=0.8).encode(**encoding_args)
                        
                    chart = chart.properties(
                        width='container',
                        height=400,
                        title=alt.TitleParams(
                            text=chart_title,
                            color='#f1f5f9',
                            font='Plus Jakarta Sans',
                            fontSize=16,
                            anchor='start'
                        )
                    ).configure_view(
                        strokeWidth=0
                    ).configure_axis(
                        gridColor='rgba(255, 255, 255, 0.05)',
                        labelColor='#94a3b8',
                        titleColor='#cbd5e1',
                        labelFont='Plus Jakarta Sans',
                        titleFont='Plus Jakarta Sans'
                    ).configure_legend(
                        labelColor='#94a3b8',
                        titleColor='#cbd5e1',
                        labelFont='Plus Jakarta Sans',
                        titleFont='Plus Jakarta Sans'
                    ).configure(
                        background='transparent'
                    ).interactive()
                    
                    st.altair_chart(chart, use_container_width=True)
                    chart_to_save = chart
                    
                elif chart_type == "Box Plot":
                    # Boxplot is best rendered via matplotlib/seaborn or Altair
                    fig, ax = plt.subplots(figsize=(10, 6))
                    fig.patch.set_facecolor('#0f172a')
                    ax.set_facecolor('#0f172a')
                    
                    sns.boxplot(
                        data=plot_df,
                        x=x_axis,
                        y=y_val,
                        hue=color_by if color_by != "None" else None,
                        palette=colors[:len(plot_df[color_by].unique())] if color_by != "None" else [colors[0]],
                        ax=ax
                    )
                    
                    # Style labels
                    ax.tick_params(colors='white', labelsize=10)
                    ax.xaxis.label.set_color('white')
                    ax.yaxis.label.set_color('white')
                    ax.spines['bottom'].set_color('rgba(255,255,255,0.1)')
                    ax.spines['left'].set_color('rgba(255,255,255,0.1)')
                    ax.spines['top'].set_visible(False)
                    ax.spines['right'].set_visible(False)
                    plt.title(chart_title, color='white', fontsize=14, pad=15)
                    st.pyplot(fig)
                    
                    chart_to_save = fig
                    
            if save_chart and chart_to_save:
                # Add to session state
                st.session_state.storyboard.append({
                    "type": "chart",
                    "content": chart_to_save,
                    "title": chart_title,
                    "meta": {
                        "type": chart_type,
                        "x": x_axis,
                        "y": y_axis,
                        "color": color_by
                    }
                })
                st.success(f"🎉 Saved '{chart_title}' to your Storyboard!")
                st.rerun()
                
        except Exception as e:
            st.error(f"Failed to generate visualization. Check if datatypes are correct for the selected axes. Details: {e}")

# ==========================================
# TAB 3: AUTOMATED INSIGHTS
# ==========================================
with tab_insights:
    st.markdown("### 💡 Automated Insights & Narrative Builder")
    
    st.markdown("""
    Our automated analytics engine scanned your dataset **{}** and uncovered the following patterns. 
    Use these insights to construct your narrative story.
    """.format(st.session_state.dataset_name))
    
    # 1. OUTLIER ANALYSIS (IQR)
    st.markdown("#### 🚨 Outlier & Anomalies Analysis")
    outlier_list = []
    
    for col in num_cols_list:
        col_data = df[col].dropna()
        if len(col_data) > 10:
            q1 = col_data.quantile(0.25)
            q3 = col_data.quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            outliers = col_data[(col_data < lower_bound) | (col_data > upper_bound)]
            if len(outliers) > 0:
                outlier_list.append({
                    "Feature": col,
                    "Normal Range": f"{lower_bound:.2f} to {upper_bound:.2f}",
                    "Outlier Count": len(outliers),
                    "% of Data": f"{(len(outliers) / len(df) * 100):.1f}%",
                    "Max Outlier": outliers.max(),
                    "Min Outlier": outliers.min()
                })
                
    if outlier_list:
        st.dataframe(pd.DataFrame(outlier_list), use_container_width=True, hide_index=True)
        st.markdown("*Outliers are computed using the Interquartile Range (IQR) method. Values exceeding 1.5x IQR from the first and third quartiles are flagged.*")
    else:
        st.info("No significant outliers detected in the numerical columns.")
        
    # 2. KEY CORRELATIONS
    st.markdown('<div class="gradient-divider" style="margin: 1.5rem 0;"></div>', unsafe_allow_html=True)
    st.markdown("#### 🔗 High-Strength Feature Correlations")
    
    if len(num_cols_list) >= 2:
        corr_matrix = df[num_cols_list].corr()
        corr_pairs = []
        
        # Get unique pairs
        for i in range(len(num_cols_list)):
            for j in range(i+1, len(num_cols_list)):
                col1 = num_cols_list[i]
                col2 = num_cols_list[j]
                val = corr_matrix.loc[col1, col2]
                if not np.isnan(val):
                    corr_pairs.append((col1, col2, val))
                    
        # Sort by absolute correlation strength
        corr_pairs.sort(key=lambda x: abs(x[2]), reverse=True)
        
        col_pair1, col_pair2 = st.columns(2)
        
        # Split display
        with col_pair1:
            st.markdown("##### ➕ Positive Relationships")
            pos_pairs = [p for p in corr_pairs if p[2] > 0.35]
            if pos_pairs:
                for col1, col2, val in pos_pairs[:5]:
                    st.markdown(f"""
                    <div class="premium-card" style="padding: 0.8rem 1.2rem; margin-bottom: 0.8rem;">
                        <span class="badge badge-indigo">+{val:.2f} Corr</span> 
                        <strong>{col1}</strong> & <strong>{col2}</strong>
                        <p style="margin: 0.3rem 0 0 0; font-size: 0.85rem; color: #94a3b8;">
                            As {col1} increases, {col2} tend to increase.
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.write("No strong positive correlations detected.")
                
        with col_pair2:
            st.markdown("##### ➖ Negative Relationships")
            neg_pairs = [p for p in corr_pairs if p[2] < -0.35]
            if neg_pairs:
                for col1, col2, val in neg_pairs[:5]:
                    st.markdown(f"""
                    <div class="premium-card" style="padding: 0.8rem 1.2rem; margin-bottom: 0.8rem;">
                        <span class="badge badge-rose">{val:.2f} Corr</span> 
                        <strong>{col1}</strong> & <strong>{col2}</strong>
                        <p style="margin: 0.3rem 0 0 0; font-size: 0.85rem; color: #94a3b8;">
                            As {col1} increases, {col2} tend to decrease.
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.write("No strong negative correlations detected.")
    else:
        st.warning("Need at least 2 numerical columns to calculate correlations.")

    # 3. DATE/TEMPORAL TRENDS
    date_cols = [col for col in df.columns if pd.api.types.is_datetime64_any_dtype(df[col])]
    if date_cols and len(num_cols_list) > 0:
        st.markdown('<div class="gradient-divider" style="margin: 1.5rem 0;"></div>', unsafe_allow_html=True)
        st.markdown(f"#### 📅 Temporal Trends (over {date_cols[0]})")
        
        target_date = date_cols[0]
        # Allow choosing numerical target
        target_num = st.selectbox("Select Target Variable for Trend Analysis:", num_cols_list, key="trend_target")
        
        # Aggregate by month/day
        trend_df = df.copy()
        trend_df['Period'] = trend_df[target_date].dt.to_period('M').astype(str)
        monthly_trend = trend_df.groupby('Period')[target_num].sum().reset_index()
        
        if len(monthly_trend) >= 2:
            # Calculate MoM growth
            monthly_trend['Prev'] = monthly_trend[target_num].shift(1)
            monthly_trend['Growth %'] = ((monthly_trend[target_num] - monthly_trend['Prev']) / monthly_trend['Prev'] * 100)
            
            # Interactive Area Chart for trend
            trend_chart = alt.Chart(monthly_trend).mark_area(
                line={'color':'#818cf8', 'size':3},
                color=alt.Gradient(
                    gradient='linear',
                    stops=[alt.GradientStop(color='rgba(129, 140, 248, 0.4)', offset=0),
                           alt.GradientStop(color='rgba(129, 140, 248, 0.0)', offset=1)],
                    x1=1, y1=1, x2=1, y2=0
                )
            ).encode(
                x=alt.X('Period:O', title='Month'),
                y=alt.Y(target_num, title=f"Total {target_num}"),
                tooltip=['Period', target_num]
            ).properties(height=300).interactive()
            
            st.altair_chart(trend_chart, use_container_width=True)
            
            # Show summary stats
            avg_growth = monthly_trend['Growth %'].dropna().mean()
            growth_text = f"positive growth of **+{avg_growth:.1f}%**" if avg_growth > 0 else f"negative growth of **{avg_growth:.1f}%**"
            st.markdown(f"Overall Month-over-Month (MoM) average growth for **{target_num}** is {growth_text}.")
            
            if st.button("💾 Save Trend Chart to Storyboard"):
                st.session_state.storyboard.append({
                    "type": "chart",
                    "content": trend_chart,
                    "title": f"Monthly Trend of {target_num}"
                })
                st.success("Saved trend chart!")
                st.rerun()

    # 4. CUSTOM ANNOTATOR
    st.markdown('<div class="gradient-divider" style="margin: 1.5rem 0;"></div>', unsafe_allow_html=True)
    st.markdown("#### 📝 Add Storyboard Observations")
    st.write("Write your findings below to compile a unified report in the next tab.")
    
    note_title = st.text_input("Observation Title", value="Key Insight Note")
    note_content = st.text_area("Write your analysis/notes here...", placeholder="Write key takeaways that support business decision-making...")
    
    if st.button("✍️ Save Note to Storyboard"):
        if note_content.strip() == "":
            st.warning("Note content cannot be empty.")
        else:
            st.session_state.storyboard.append({
                "type": "note",
                "content": note_content,
                "title": note_title
            })
            st.success("Note saved to storyboard!")
            st.rerun()

# ==========================================
# TAB 4: STORYBOARD & REPORTING
# ==========================================
with tab_storyboard:
    st.markdown("### 📝 Compiled Data Storyboard")
    
    if not st.session_state.storyboard:
        st.info("Your Storyboard is empty. Go to **Interactive Chart Builder** or **Automated Insights** and save items to see them compiled here!")
    else:
        st.write("Review, reorganize, and export your data story.")
        
        # Storyboard compiler
        for idx, item in enumerate(st.session_state.storyboard):
            st.markdown(f'<div class="premium-card">', unsafe_allow_html=True)
            
            col_header, col_delete = st.columns([8, 1])
            with col_header:
                st.markdown(f"##### Item #{idx+1}: {item['title']} <span class='badge badge-indigo'>{item['type'].upper()}</span>", unsafe_allow_html=True)
            with col_delete:
                if st.button("🗑️ Delete", key=f"del_{idx}"):
                    st.session_state.storyboard.pop(idx)
                    st.success("Item deleted!")
                    st.rerun()
            
            if item["type"] == "chart":
                chart_obj = item["content"]
                if isinstance(chart_obj, plt.Figure):
                    st.pyplot(chart_obj)
                else: # Altair chart
                    st.altair_chart(chart_obj, use_container_width=True)
            else:
                st.markdown(f'<div class="annotation-box">{item["content"]}</div>', unsafe_allow_html=True)
                
            st.markdown('</div>', unsafe_allow_html=True)
            
        # Compile Report Generation
        st.markdown('<div class="gradient-divider" style="margin: 2rem 0;"></div>', unsafe_allow_html=True)
        st.markdown("#### 📤 Export Narrative Report")
        
        report_title = st.text_input("Report Header Title", value="Executive Data Insights Summary")
        report_author = st.text_input("Author Name", value="Lead Data Analyst")
        
        # Build HTML output
        html_buffer = io.StringIO()
        html_buffer.write(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>{report_title}</title>
            <style>
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #0b0f19;
                    color: #f1f5f9;
                    padding: 3rem;
                    line-height: 1.6;
                }}
                .container {{
                    max-width: 900px;
                    margin: 0 auto;
                }}
                h1 {{
                    font-size: 2.5rem;
                    background: linear-gradient(135deg, #818cf8 0%, #c084fc 100%);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    border-bottom: 2px solid rgba(255,255,255,0.05);
                    padding-bottom: 1rem;
                    margin-bottom: 0.5rem;
                }}
                .meta {{
                    color: #94a3b8;
                    margin-bottom: 3rem;
                    font-size: 0.95rem;
                }}
                .card {{
                    background: rgba(30, 41, 59, 0.45);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 12px;
                    padding: 1.5rem;
                    margin-bottom: 2rem;
                }}
                .card h3 {{
                    margin-top: 0;
                    color: #a5b4fc;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
                    padding-bottom: 0.5rem;
                }}
                .note {{
                    background: rgba(99, 102, 241, 0.05);
                    border-left: 4px solid #6366f1;
                    padding: 1rem;
                    color: #e2e8f0;
                    white-space: pre-line;
                }}
                .footer {{
                    text-align: center;
                    color: #64748b;
                    margin-top: 5rem;
                    font-size: 0.85rem;
                    border-top: 1px solid rgba(255,255,255,0.05);
                    padding-top: 1rem;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>{report_title}</h1>
                <div class="meta">
                    Report Compiled by: <strong>{report_author}</strong> | Date: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}
                </div>
        """)
        
        # Add items to HTML
        for idx, item in enumerate(st.session_state.storyboard):
            html_buffer.write(f"""
                <div class="card">
                    <h3>Item #{idx+1}: {item['title']} ({item['type'].upper()})</h3>
            """)
            if item["type"] == "chart":
                # Put a placeholder in HTML noting there was a chart
                html_buffer.write(f"""
                    <p style="color: #94a3b8; font-style: italic;">[Interactive Chart: {item['title']}]</p>
                """)
            else:
                html_buffer.write(f"""
                    <div class="note">{item['content']}</div>
                """)
            html_buffer.write("</div>")
            
        # Add footer
        html_buffer.write("""
                <div class="footer">
                    Generated via NovaVis Report Compiler. All rights reserved.
                </div>
            </div>
        </body>
        </html>
        """)
        
        st.download_button(
            label="📥 Download Compiled HTML Report",
            data=html_buffer.getvalue(),
            file_name="NovaVis_Data_Story_Report.html",
            mime="text/html"
        )
