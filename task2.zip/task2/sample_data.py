import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def get_sales_data():
    """Generates a rich mock SaaS E-Commerce Sales dataset."""
    np.random.seed(42)
    n_rows = 500
    
    # Generate dates over the last 365 days
    start_date = datetime.now() - timedelta(days=365)
    dates = [start_date + timedelta(days=int(i)) for i in np.random.randint(0, 365, n_rows)]
    dates.sort()
    
    categories = ["Software License", "Cloud Subscription", "Consulting Service", "Hardware Support"]
    regions = ["North America", "Europe", "Asia-Pacific", "Latin America"]
    segments = ["Enterprise", "Mid-Market", "SMB"]
    
    # Probabilities for categories, regions, segments to make it realistic
    cat_choices = np.random.choice(categories, n_rows, p=[0.4, 0.35, 0.15, 0.1])
    region_choices = np.random.choice(regions, n_rows, p=[0.45, 0.3, 0.15, 0.1])
    segment_choices = np.random.choice(segments, n_rows, p=[0.3, 0.4, 0.3])
    
    # Base revenue based on category and segment
    base_revenue = {
        "Software License": 2500,
        "Cloud Subscription": 1200,
        "Consulting Service": 5000,
        "Hardware Support": 800
    }
    
    segment_multiplier = {
        "Enterprise": 2.5,
        "Mid-Market": 1.2,
        "SMB": 0.6
    }
    
    revenue = []
    units_sold = []
    
    for cat, seg in zip(cat_choices, segment_choices):
        # Base units
        u = np.random.randint(1, 10)
        units_sold.append(u)
        
        # Calculate revenue with some noise
        base = base_revenue[cat] * segment_multiplier[seg] * u
        noise = np.random.normal(0, base * 0.1) # 10% noise
        rev = max(50.0, round(base + noise, 2))
        revenue.append(rev)
        
    satisfaction = np.random.choice([3, 4, 5], n_rows, p=[0.15, 0.45, 0.4])
    # Introduce some lower scores for consulting to make it interesting
    for i in range(n_rows):
        if cat_choices[i] == "Consulting Service" and np.random.rand() < 0.25:
            satisfaction[i] = np.random.choice([1, 2], p=[0.4, 0.6])
            
    df = pd.DataFrame({
        "Date": dates,
        "Product Category": cat_choices,
        "Region": region_choices,
        "Customer Segment": segment_choices,
        "Revenue ($)": revenue,
        "Units Sold": units_sold,
        "Customer Satisfaction": satisfaction
    })
    return df

def get_support_data():
    """Generates a mock Tech Support Performance dataset."""
    np.random.seed(101)
    n_rows = 300
    
    priorities = ["Low", "Medium", "High", "Critical"]
    p_weights = [0.4, 0.35, 0.18, 0.07]
    priority_choices = np.random.choice(priorities, n_rows, p=p_weights)
    
    agents = ["Alice Vance", "Bob Miller", "Charlie Smith", "Diana Prince", "Evan Wright"]
    agent_choices = np.random.choice(agents, n_rows)
    
    channels = ["Email", "Live Chat", "Phone Support", "Web Portal"]
    channel_choices = np.random.choice(channels, n_rows, p=[0.3, 0.4, 0.2, 0.1])
    
    statuses = ["Closed", "Open", "Pending"]
    
    # Priority influences resolution time
    # Critical should be resolved faster on average, but might have higher outliers if pending
    res_time_base = {
        "Low": 48.0,
        "Medium": 24.0,
        "High": 8.0,
        "Critical": 2.0
    }
    
    resolution_times = []
    status_choices = []
    
    for priority in priority_choices:
        base = res_time_base[priority]
        # Generate time with lognormal distribution to have long tails (outliers)
        time = np.random.lognormal(mean=np.log(base), sigma=0.5)
        resolution_times.append(round(time, 1))
        
        # Newer tickets or critical ones might be open or pending
        rand_val = np.random.rand()
        if priority == "Critical" and rand_val < 0.15:
            status_choices.append("Open")
        elif rand_val < 0.05:
            status_choices.append("Open")
        elif rand_val < 0.12:
            status_choices.append("Pending")
        else:
            status_choices.append("Closed")
            
    # For open/pending tickets, resolution time is null or current duration
    # We'll set resolution time to NaN for open/pending to make it realistic for data cleaning exercises
    for i in range(n_rows):
        if status_choices[i] in ["Open", "Pending"]:
            resolution_times[i] = np.nan
            
    df = pd.DataFrame({
        "Ticket ID": [f"T-{1000+i}" for i in range(n_rows)],
        "Priority": priority_choices,
        "Assigned Agent": agent_choices,
        "Channel": channel_choices,
        "Status": status_choices,
        "Resolution Time (hrs)": resolution_times
    })
    return df
